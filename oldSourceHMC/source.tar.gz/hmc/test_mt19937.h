/* 
 * File:   test_mt19937.h
 * Author: Sreekumar Balan
 * Email: st452@mrao.cam.ac.uk
 *
 * Created on 30 September 2012
 */
 
#ifndef ELLIPSIS_TEST_MT19937_H
#define ELLIPSIS_TEST_MT19937_H
 
int test_random_uni();
int test_random_norm();
int test_rand_save_state();

 
#endif/*ELLIPSIS_TEST_MT19937_H*/

