/* 
 * File:   test_hanson.h
 * Author: Sreekumar Balan
 * Email: st452@mrao.cam.ac.uk
 *
 * Created on 30 September 2012
 */

#ifndef ELLIPSIS_TEST_HANSON_H
#define ELLIPSIS_TEST_HANSON_H

int test_hanson_diag();
int test_csv_IO();



#endif/*ELLIPSIS_TEST_HANSON_H*/
